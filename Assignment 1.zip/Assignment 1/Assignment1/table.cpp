#include "table.h"


    float table::getFriction(){
        return friction;
    }
     float table::getYsize(){
        return y_size;
    }

    float table::getXsize(){
        return x_size;
    }

   std::string table::getColour(){
        return colour;
    }

