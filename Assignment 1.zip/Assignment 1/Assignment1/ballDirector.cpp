#include "balldirector.h"


ball* ballDirector::Construct(){


    builder->buildBallShell();
    ball* b = builder->getBall();
    return b;
}
